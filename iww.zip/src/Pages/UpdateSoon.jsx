import React from 'react'
import "../css/UpdateSoon.css"

const UpdateSoon = () => {
  return (
    <div>
      <div className='update-soon-div'>
        <span className='update-soon-span'>Update Soon..... </span></div>
    </div>
  )
}

export default UpdateSoon